#include <iostream>
#include <string>
#include <vector>
#include "Card.h"
#include "Deck.h"
using namespace std;
using std::vector;

/*
 * description: this function converts a card value to a string
 * so that we can format cards
 */
std::string ValueToString(Value value) {
    switch (value) {
        case ace:
            return "A";
        case king:
            return "K";
        case queen:
            return "Q";
        case jack:
            return "J";
        default:
            return std::to_string(value);
    }
}

std::string SuitToString(Suit suit) {
    switch (suit) {
        case clubs:
            return "C";
        case diamonds:
            return "D";
        case hearts:
            return "H";
        case spades:
            return "S";
        default:
            std::cout << "Invalid suit" << std::endl;
            return "";
    }
}

/*
 * description: formats a card as value followed by string
 */
std::string CardToString(Card card) {
    return ValueToString(card.GetValue()) + SuitToString(card.GetSuit());
}

void PrintDeck(Deck deck) {
    for (Card card : deck._deck) {
        std::cout << CardToString(card)<< std::endl;
    }
}

/*
 * description: returns the value of cards in your hand as an int
 */
int handValue(vector<Card> hand) {
    int total = 0;

    for (auto & go : hand) {
        if (go.GetValue() >= 10) {
            total += 10;
        } else
            total += go.GetValue();
    }
    return total;
}

/*
 * description: prints out cards in your hand
 */
void printHand(vector<Card> hand) {
    for (auto & go : hand) {
        cout << CardToString(go) + " ";
    }
}

int main() {
    Suit suit = hearts;
    Value value = two;
    Card card = Card(value, suit);
    Deck deck;
    bool dealerBlackjack = false;
    bool playerBlackjack = false;
    string choice;
    //char hit = 'h';
    //char stand = 's';
    //int playerValue;

    vector<Card> dealerHand;
    vector<Card> playerHand;

    dealerHand.push_back(deck.DrawCard());
    dealerHand.push_back(deck.DrawCard());
    playerHand.push_back(deck.DrawCard());
    playerHand.push_back(deck.DrawCard());

    cout << "The dealer's hand: " << CardToString(dealerHand[0]) + " (face down card)" << endl;
    cout << "The player's hand: " << CardToString(playerHand[0]) + " " + CardToString(playerHand[1]) << endl;
    cout << endl;


    if (ValueToString(dealerHand[0].GetValue()) == "A" && ValueToString(dealerHand[1].GetValue()) == "10") {
        dealerBlackjack = true;
    }
    if (ValueToString(playerHand[0].GetValue()) == "A" && ValueToString(playerHand[1].GetValue()) == "10") {
        playerBlackjack = true;
    }
    if (ValueToString(playerHand[1].GetValue()) == "A" && ValueToString(playerHand[0].GetValue()) == "10") {
        playerBlackjack = true;
    }

    while (true) {
        if (dealerBlackjack && playerBlackjack) {
            cout << "Both parties have blackjack. Tie!" << endl;
            break;
        } else if (playerBlackjack && !dealerBlackjack) {
            cout << "The player has blackjack and the dealer does not. Player has won!" << endl;
            break;
        } else if (!playerBlackjack && dealerBlackjack) {
            cout << "The dealer has blackjack and the player does not. Dealer has won!" << endl;
            break;
        } else
            cout << "Hit or stand? (Enter h or s): ";
            cin >> choice;

            while (choice == "h") {
                playerHand.push_back(deck.DrawCard());
                if (handValue(playerHand) < 21) {
                    printHand(playerHand);
                    cout << endl;
                    cout << "players value is: " << handValue(playerHand) << endl;
                    cout << endl;
                    cout << "Hit or stand? (Enter h or s): ";
                    cin >> choice;

                } else if (handValue(playerHand) > 21) {
                    printHand(playerHand);
                    cout << endl;
                    cout << "players value is: " << handValue(playerHand) << endl;
                    cout << endl;
                    cout << "Bust, dealer wins!";
                    break;
                }

            }
            if (choice == "s") {
                while (handValue(dealerHand) <= 17 && handValue(dealerHand) < 21) {
                    dealerHand.push_back(deck.DrawCard());
                }
                if (handValue(dealerHand) > 21) {
                    cout << "dealer has busted, player wins!" << endl;
                    break;
                }
                cout << endl;
                cout << "dealers hand is: ";
                printHand(dealerHand);
                cout << endl;
                cout << "dealers value is: " << handValue(dealerHand) << endl;
                cout << endl;
                cout << "players hand is: ";
                printHand(playerHand);
                cout << endl;
                cout << "players value is: " << handValue(playerHand) << endl;
                cout << endl;
                if (handValue(playerHand) == handValue(dealerHand)) {
                    cout << "game ends in a TIE!" << endl;
                } else if (handValue(playerHand) > handValue(dealerHand) && handValue(playerHand) <= 21) {
                    cout << "player won!" << endl;
                } else
                    cout << "dealer won!" << endl;


            }
            break;
    }

    return 0;
}
