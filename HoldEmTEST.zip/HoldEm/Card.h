//
// Created by peter on 1/28/21.
//

#ifndef HOLDEM_CARD_H
#define HOLDEM_CARD_H

enum Suit {clubs, diamonds, hearts, spades};
enum Value {two = 2, three, four, five, six, seven, eight,
        nine, ten, jack, queen, king, ace};
class Card {
public:
    Card();
    Card(Value value, Suit suit);
    Value GetValue();
    Suit GetSuit();
private:
    Value _value;
    // suit will hold 'C' | 'D' | 'H' | 'S'
    Suit _suit;
};


#endif //HOLDEM_CARD_H
