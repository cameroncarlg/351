//
// Created by peter on 2/2/21.
//

#ifndef HOLDEM_DECK_H
#define HOLDEM_DECK_H
#include <vector>
#include "Card.h"

class Deck {
public:
    Deck();
    Card DrawCard();
    void PrintDeck();
    std::vector<Card> _deck;
};


#endif //HOLDEM_DECK_H
