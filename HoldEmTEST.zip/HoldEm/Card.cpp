//
// Created by peter on 1/28/21.
//

#include "Card.h"


Card::Card() {
    Suit card_suit = hearts;
    Value card_value = two;
}

Card::Card(Value value, Suit suit) {
    _value = value;
    _suit = suit;
}

Value Card::GetValue() {
    return _value;
}

Suit Card::GetSuit() {
    return _suit;
}

