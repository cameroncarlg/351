//
// Created by peter on 9/16/20.
//

#include "ArrayVector.h"
#include <algorithm>
#include <iostream>



ArrayVector::ArrayVector(size_t av_size) {
    ArrayVector::total_elements = av_size;
}

ArrayVector::ArrayVector(size_t other_sz, int *other_array) {
    ArrayVector::total_elements = other_sz;
    ArrayVector::array_for_vector = other_array;
}

void ArrayVector::AddArray(size_t arg_size, int *other_array) {
    ArrayVector::total_elements = arg_size;
    ArrayVector::array_for_vector = other_array;

}

int ArrayVector::Get(size_t index) {
    //return array_for_vector[index];
}

int ArrayVector::Pop() {

}

void ArrayVector::AddSpace() {

}
void ArrayVector::AddSpace(size_t s) {

}

void ArrayVector::PushBack(int val) {
    AddSpace();
}

void ArrayVector::Insert(size_t index, int val) {
    AddSpace();

}

void ArrayVector::Remove(int val) {

}



int ArrayVector::Sum() {
    return -1;
}

int ArrayVector::Max() {
    return -1;
}

int ArrayVector::Min() {
    return -1;
}

double ArrayVector::Average() {
    return -1;
}

ArrayVector::~ArrayVector() {
    delete [] array_for_vector;
}

void ArrayVector::PrintVector() {
    for (unsigned i = 0; i < total_elements; i++) {
        std::cout << array_for_vector[i] << std::endl;
    }

}
