#include <iostream>
#include <fstream>
#include <random>
#include "ArrayVector.h"
#include <string>
using std::cout;
using std::cin;
using std::endl;

int main() {
    /*
    int score;
    std::fstream grades_input_file("grades.txt");
    auto grade_vector = ArrayVector(5);
    while (grades_input_file >> score){
        grade_vector.PushBack(score);
    }
     */


    int sample_array[] = {1, 2, 3};
    size_t sample_size = 3;
    auto test_vector = ArrayVector(sample_size, sample_array);
    test_vector.PrintVector();


    int x = 3;
    int* a = &x;

    cout << a << endl;



    /*
    std::cout << "The worst grade is: " << competition_vector.Min() << std::endl;
    std::cout << "The best grade is: " << competition_vector.Max() << std::endl;
    std::cout << "The average grade is: " << competition_vector.Average() << std::endl;
    */
    return 0;
}
